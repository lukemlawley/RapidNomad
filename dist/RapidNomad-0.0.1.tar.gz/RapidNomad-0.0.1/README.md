# RapidNomad

This is my Geog 422 class project
